jQuery(document).ready(function(){	
function {{uc_id}}_start(){
  
  var objBar = jQuery("#{{uc_id}}");
  var objProgress = objBar.find(".progress-all");
  var isVisible = isElementInViewport(objBar);
  var objParentTempalteSwitcher = objBar.parents(".uc-template-holder");
  var isInsideTemplateSwitcher = objParentTempalteSwitcher && objParentTempalteSwitcher.length > 0;
  var objParentSimplePopup = objBar.parents(".ue-simple-popup");
  var isInsideSimplePopup = objParentSimplePopup && objParentSimplePopup.length > 0;
  
  /**
  * start function
  */
  function startBar(){    
  	var waypoints = objBar.waypoint({
    	handler: function(direction) {
            objProgress.asProgress({'namespace': 'progressnew'});
        	objProgress.asProgress('start');
        },
        offset: "100%"
     });        
  }
  
  /**
  * check if in viewport
  */
  function isElementInViewport(objElement) {
		  
		  var elementTop = objElement.offset().top;
		  var elementBottom = elementTop + objElement.outerHeight();

		  var viewportTop = jQuery(window).scrollTop();
		  var viewportBottom = viewportTop + jQuery(window).height();

		  return (elementBottom > viewportTop && elementTop < viewportBottom);
  } 
  
  /**
  * init for simple popup
  */
  function initForSimplePopup(){
    if(isInsideSimplePopup == false)
      return(false);
    
    var objSimplePopupBtn = objParentSimplePopup.find(".ue-simple-popup-trigger");
    
    objSimplePopupBtn.on("click", function(){
           var isInited = objBar.data("inited");
          	if(isInited == true)
              return(true);
                
           var isVisible = isElementInViewport(objBar);
           if(isVisible){
               objBar.data("inited", true);
              startBar();
           }   
    });
  }
  
  //do not init if in Simple Popup, or is not in viewport
  if(isVisible && isInsideSimplePopup == false || isInsideTemplateSwitcher == true && isInsideSimplePopup == false){
      startBar();
  }else{
  	jQuery(window).on("scroll",function(){
        var isInited = objBar.data("inited");
        if(isInited == true)
        	return(true);
      
        if(isInsideSimplePopup == true)
         return(true);
            
        var isVisible = isElementInViewport(objBar);
        if(isVisible){
        	objBar.data("inited", true);
            startBar();
    	}
            
  	});
  }
  
  initForSimplePopup();
  
}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});