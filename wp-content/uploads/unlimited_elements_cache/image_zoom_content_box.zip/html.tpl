<div class="uc_content_box_zoom_effect ue-box ue-box{{layout}}" id="{{uc_id}}"> 
  
  
    <div class="uc_thumbnail">
      {% if link_image == "true" %}<a href="{{link}}" {{link_html_attributes|raw}}>{% endif %}
  	      <img class="uc_image uc_content_box_zoom_effect_image" src="{{image}}" {{image_attributes|raw}} />
      {% if link_image == "true" %}</a>{% endif %}
    </div>
  
  
  <div class="uc_content_box_zoom_effect_content">
    {% if show_title == "true" %}
         {% if link_title == "true" %}<a href="{{link}}" >{% endif %}
                   <{{title_tag}} class="uc_title">{{title|raw}}</{{title_tag}}>
        {% if link_title == "true" %}</a>{% endif %}
    {% endif %}
    {% if show_description == "true" %}<div class="uc_content" style="text-align:{{align}};">{{description|raw}}</div>{% endif %}
    {% if show_button == "true" %}<a href="{{link}}" {{link_html_attributes|raw}} class="uc_more" style="display:{{show_btn}};border-radius:{{radius}}px;">{{read_more_txt|raw}}</a> {% endif %}
  </div>
</div>