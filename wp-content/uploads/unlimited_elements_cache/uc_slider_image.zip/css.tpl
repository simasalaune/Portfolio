#{{uc_id}}{
  overflow:hidden;
}

#{{uc_id}}-wrapper{
  min-height:1px;
}