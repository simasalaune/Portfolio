{% set url_cart = ucfunc("get_woo_endpoint","cart") %}
{% set url_checkout = ucfunc("get_woo_endpoint","checkout") %}

<div id="{{uc_id}}" class="ue-mini-cart_wrapper">
 <div id="{{uc_id}}" class="ue-mini-cart_container">
   
  {% if show_toggle_button == "true" %}
    <div class="ue_mini_cart_toggle">
      {% if show_toggle_icon == "true" %}{{toggle_icon_html|raw}}{% endif %}{{toggle_text}}
      {% if show_cart_total_in_toggle == "true" %}<div class="uc-mini-cart-toggle-subtotal">{{ucfunc("put_woo_cart_html","total2")}}</div>{% endif %}
      {% if show_products_count == "true" %}<div class="ue-product-count">{{ucfunc("put_woo_cart_html","num_products")}}</div>{% endif %}
    </div>
  {% endif %}

  <div id="{{uc_id}}" class="ue-mini-cart" {% if show_toggle_button == "true" %}style="display:none;"{% endif %}>
    <div class="ue_cart_header">
      {% if show_cart_title == "true" %}<div class="ue-mini-cart-title">{{cart_title|raw}}</div>{% endif %}
      {% if show_cart_close_button == "true" %}<div class="ue_cart_close_button">{{cart_close_button_html|raw}}</div>{% endif %}
    </div>

      {{ucfunc("put_woo_cart_html","items")}}

    <div class="ue-mini-cart-footer">

      <div class="ue-mini-cart-empty-message">{{empty_message_text|raw}}</div>
      {% if show_subtotal == "true" %}
        <div class="ue-mini-cart-subtotal">{{show_text|raw}}
          {% if fill_gap_with_dashes == "true" %}<span class="ue-total-gap-dots"></span>{% endif %}
          <div class="ue_subtotal_amount">
              {{ucfunc("put_woo_cart_html","total")}}
           </div>
        </div>
      {% endif %}

      <div class="ue_cart_btn_wrapper">
         {% if show_cart_button == "true" %}<a href="{{url_cart}}" class="ue-mini-cart-viewcart-btn">{{cart_button_text|raw}}</a>{% endif %}
         {% if show_checkout_button == "true" %}<a href="{{url_checkout}}" class="ue-mini-cart-checkout-btn" data-hide="{{hide_checkout_button_cart_empty}}">{{checkout_button_text|raw}}</a>{% endif %}
      </div>
    </div>
  </div>
   
 </div>
</div>