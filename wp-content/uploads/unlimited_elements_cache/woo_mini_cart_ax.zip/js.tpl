{{ ucfunc("put_docready_start") }}
  
  var objWidget = jQuery("#{{uc_id}}");
  var shopPageUrl = "{{ucfunc('get_woo_endpoint', 'shop')}}";
    
  var objMinicart = new ueMiniCart();

  objMinicart.init(objWidget, shopPageUrl);

  var miniCartElement = objWidget.find(".ue-mini-cart");
  var miniCartCloseButton = objWidget.find(".ue_cart_close_button");
  var miniCartToggleButton = objWidget.find(".ue_mini_cart_toggle");
  var bodyElement = jQuery("body");

  var miniCartFadeInOutDuration = {{mini_cart_fade_in_out_duration}};
  var miniCartHideDelay = {{mini_cart_hide_delay}};

  /**
  * fade in
  */
  function miniCartFadeIn(){  
    miniCartElement.fadeIn(miniCartFadeInOutDuration);  
  }

  /**
  * fade out
  */
  function miniCartFadeOut(){  
    miniCartElement.stop().fadeOut(miniCartFadeInOutDuration);  
  }

  {% if show_toggle_button == "true" %}
   {% if mini_cart_trigger == "hover" %}

    var hoverTimeout;

    // Show mini cart on hover
    miniCartToggleButton.hover(function() {
      clearTimeout(hoverTimeout);

      miniCartFadeIn();
    }, function() {
      hoverTimeout = setTimeout(function() {

        miniCartElement.fadeOut(miniCartFadeInOutDuration);
      }, miniCartHideDelay);
    });

    // Keep mini cart open when hovered over it
    miniCartElement.hover(function() {
      clearTimeout(hoverTimeout);

      miniCartElement.stop().fadeIn(miniCartFadeInOutDuration);
    }, function() {
      hoverTimeout = setTimeout(function() {

        miniCartFadeOut();
      }, miniCartHideDelay);
    });
   {% endif %}


   {% if mini_cart_trigger == "click" %}
    // Show/hide the mini cart on click
    miniCartToggleButton.click(function() {
      miniCartElement.fadeToggle(miniCartFadeInOutDuration);
    });
   {% endif %}

   {% if mini_cart_trigger == "click_add_to_cart" %}    
      // Show/hide the mini cart on click
      miniCartToggleButton.click(function() {
        miniCartElement.fadeToggle(miniCartFadeInOutDuration);
      });

      // Show/hide the mini cart on added to cart
      bodyElement.on("added_to_cart", miniCartFadeIn);
   {% endif %} 

   //close mini cart
   miniCartCloseButton.on("click", miniCartFadeOut); 
  {% endif %}
  
{{ ucfunc("put_docready_end") }}