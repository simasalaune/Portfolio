<div id="{{uc_id}}" class="ue-badge" data-badge-side="{{badge_side}}">	
  <div class="ue-badge-rotated-forward">    
    <div class="ue-badge-rotated-reverse">
      <div class="ue-badge-container">
      
        {% if show_title == "true" %}
          <div class="ue-badge-title">{{badge_title|raw}}</div>
        {% endif %}	

        {% if show_icon == "true" %}
          <div class="ue-badge-icon">{{ue_badge_icon_html|raw}}</div>
        {% endif %}
      </div>
    </div>
  </div>
</div>