jQuery(document).ready(function(){	
function {{uc_id}}_start(){
		
  var objCarousel = jQuery('#{{uc_id}}');
  
  		objCarousel.owlCarousel({
			    loop: {{loop}},
                rewind:{{navigation_rewind}},
                paddingType: "{{stage_padding_type}}",
                navText: ["<i class='{{left_arrow}}'></i>","<i class='{{right_arrow}}'></i>"],
                nav: {{show_arrows}},
                navigation:true,
                rtl:{{rtl}},
                center:{{center}},
                dots:{{show_dots}},
                autoplayTimeout:{{autoplay_interval}},
                smartSpeed: {{transition_speed}},  
                autoplay: {{autoplay}},
				margin: {{margin_between_items}},
                responsive : {
					0 : {
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stagepadding_mobile}},
                        {% endif %}           
						items:{{number_of_items_mobile}}
					},
					768 : {
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stagepadding_tablet}},
                        {% endif %}        
						items:{{number_of_items_tablet}}
					},
					980 : {
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stagepadding}},
                        {% endif %}         
						items:{{number_of_items}}
					} 
			}
		  });
  
		{{ucfunc("put_remote_parent_js","objCarousel")}}  

}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});