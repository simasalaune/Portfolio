{% if rtl == "false" %}<div class="uc_overlay_image_carousel"  style="direction:ltr;"> {% endif %}
{% if rtl == "true" %}<div class="uc_overlay_image_carousel"  style="direction:rtl;"> {% endif %}
   <div class="uc_carousel owl-carousel owl-theme {{remote_parent.class}}" id="{{uc_id}}" {{remote_parent.attributes|raw}}>
     
   <!-- start item -->
   {% for term in woocommerce_categories %}
     {% if custom_image_field == "true" %}{% set image = ucfunc("get_term_image",term.id,custom_image_field_name) %}{% endif %}
      
      {% if (show_with_images == "false") or (show_with_images == "true" and term.image) or (show_with_images == "true" and custom_image_field == "true" and image is not empty) %}
      <div class="uc_image_carousel_container_holder ue-item">
            <div class="uc_image_carousel_placeholder">
              <a href="{{term.link}}" target="{{open_link_in_new_tab}}">
                
					{% if custom_image_field == "false" %}                        
                         <div style="background-image:url({{term.image}});" class="carousel-image"></div>                        
				 	{% else %}
                          {% if image is not empty %}    
                				<div style="background-image:url({{image.thumb_large}});" class="carousel-image"></div>
                          {% else %}
                              <div  class="carousel-image"></div>
                          {% endif %}                        
                    {% endif %}

				</a>
            </div>

            <div class="uc_image_carousel_content content-padding">
              <div>
              {% if show_title == "true" or show_number_of_products == "true" %}{% if show_title == "true" %}<div class="uc_post_title"><a href="{{term.link}}" target="{{open_link_in_new_tab}}">{% if category_characters_number is not empty %}{{term.name|truncate(category_characters_number)|raw}}{% else %}{{term.name|raw}}{% endif %}</a>{% endif %}
				{% if show_number_of_products == "true" %}
                               <span class="uc_cat_carousel_style_one_item_num_posts_spacer"></span>
                               <span class="uc_cat_carousel_style_one_item_num_posts"><span class="text_before_num">{{text_before_post_num|raw}}</span>{{term.num_posts}}<span class="text_after_num">{{text_after_post_num|raw}}</span></span>
                {% endif %}
              </div>{% endif %}
              {% if show_intro == "true" %}<div class="uc_paragraph" >{{term.description}}</div>{% endif %}
              {% if show_button == "true" %}<a class="uc_more_btn"  href="{{term.link}}" target="{{open_link_in_new_tab}}"><div class="ue-btn-inner-wrapper">{{button_text|raw}}<div class="ue_btn_icon">{{button_icon_html|raw}}</div></div></a>{% endif %}
              </div>
            </div>
          </div>
          {% endif %}
      
     {% endfor %}
     <!-- end item -->
     
   </div>	
</div>