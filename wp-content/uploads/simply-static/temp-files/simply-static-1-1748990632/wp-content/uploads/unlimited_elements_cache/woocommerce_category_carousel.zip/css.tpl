#{{uc_id}} *{
  box-sizing:border-box;
}
.uc_carousel *
{
  transition: all {{transition_time}}s ease-in-out;
}
#{{uc_id}}{
  position:relative;
  min-height:1px;
}
.uc_post_grid_style_one .ue_taxonomy_image {
	background-color: white;
	padding:16px;
}
.uc_post_grid_style_one .ue_taxonomy_image .uc-term-image{
	width:100%;
	height:100%;
}
#{{uc_id}} .uc_post_title{
  font-size:21px;
}
{% if spacing_type == "full" %}
#{{uc_id}} .uc_post_title{
  width:100%;
  display:flex;
  align-items:center;
  justify-content:space-between;
}
{% endif %}
#{{uc_id}} .carousel-image{
  background-repeat: no-repeat;
}

#{{uc_id}}  .owl-nav .owl-prev{
    position:absolute;
    display:inline-block;
    text-align:center;
}
#{{uc_id}} .owl-nav .owl-next{
  position:absolute;
  display:inline-block;
  text-align:center;
}

#{{uc_id}} .owl-carousel .owl-nav .owl-prev:after{
    content: "{{arrow_left|raw}}";
}
#{{uc_id}} .owl-carousel .owl-nav .owl-next:after{
    content: "{{arrow_right|raw}}";
}

#{{uc_id}} .uc_image_carousel_container_holder{
  text-align:{{text_align}};
  overflow:hidden;
}

#{{uc_id}} .uc_more_btn{
    display:{{button_style}};
    text-align:center;
  	transition: all 0.12s ease-in-out;
}
#{{uc_id}} .uc_more_btn .ue-btn-inner-wrapper{
  	transition: none!important;
}
#{{uc_id}} .owl-dots {
overflow:hidden;
 display:{{show_dots}} !important;
text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {
border-radius:50%;
display:inline-block;
}

{% if layout == "overlay" %}
	#{{uc_id}} .uc_image_carousel_content    {
      position:absolute;
      top:{{content_top}}px;
      left:{{content_left}}px;
      bottom:{{content_bottom}}px;
      right:{{content_right}}px;
      opacity:0;
      display:flex;
     
      flex-direction:column;
      
    }

	#{{uc_id}} .uc_image_carousel_container_holder:hover .uc_image_carousel_content{
      opacity:1;
    }

{% endif %}

#{{uc_id}} .uc_date{
  color:gray;
  padding-top:10px;
  text-style:italic;
}
#{{uc_id}} .ue-btn-inner-wrapper{
  display:flex;
  align-items:center;
}
#{{uc_id}} .ue-btn-inner-wrapper .ue_btn_icon
{
  	display:flex;
 	height:100%; 
    transition:none!important;
}
{% if layout == "partial_overlay" %}
	#{{uc_id}} .uc_image_carousel_content{
     position:absolute;
     
     bottom:{{content_bottom}}px;
     left:{{content_left}}px;
     right:{{content_right}}px;
    }
{% endif %}



{% if layout == "under_overlap" %}
	#{{uc_id}} .uc_image_carousel_content{
     
      
      position:relative;
    }
{% endif %}

{% if layout == "reveal_from_bottom" %}
	#{{uc_id}} .uc_image_carousel_content{
        
        position:absolute;
      	bottom: -100%;
        left: 0;
        right: 0;
        
    }
    #{{uc_id}} .uc_image_carousel_container_holder:hover .uc_image_carousel_content{
		bottom: 0;
    }
{% endif %}
{% if spacing_type == "full" %}
	#{{uc_id}} .uc_image_carousel_content>div{
       width:100%!important;
    }
    
{% endif %}

{% if layout == "side_by_side" %}
	#{{uc_id}} .uc_image_carousel_container_holder
    {
      display:flex;
    }
    #{{uc_id}} .uc_image_carousel_container_holder > div 
   {
     width:50%;
     
   }
   #{{uc_id}} .uc_image_carousel_container_holder .uc_image_carousel_content
   {
     display:flex;
     flex-direction:column;
   }
{% endif %}
#{{uc_id}} .uc_cat_carousel_style_one_item_num_posts_spacer
{
  display: inline-block;
  
  
}

{% if make_3d == "true" %} 
#{{uc_id}} .ue-item {
	opacity: 0.3;
	transform: scale3d(0.8, 0.8, 1);
	
}

#{{uc_id}} .active.center .ue-item {
	opacity: 1;
	transform: scale3d(1, 1, 1);
	
}
{% endif %}

#{{uc_id}} .owl-nav .owl-prev.disabled,
#{{uc_id}} .owl-nav .owl-next.disabled {
   display: none;
}