{{ ucfunc("put_docready_start") }}
		
	var objBadge = jQuery('#{{uc_id}}');
  	var objForwardWrap = objBadge.find('.ue-badge-rotated-forward');
	var objReverseWrap = objBadge.find('.ue-badge-rotated-reverse'); 
  	var objBadgeContainer = objBadge.find('.ue-badge-container');
	var objFirstParent = objBadge.parent();
    var objSecondParent = objFirstParent.parent();
  
  	var topLeftClass = 'ue-badge-top-left';
    var topRightClass = 'ue-badge-top-right';
    var bottomRightClass = 'ue-badge-bottom-right';
    var bottomLeftClass = 'ue-badge-bottom-left';
  	var fullOpacityClass = 'ue-opacity-full';
  
  	var dataBadgeSide = objBadge.data('badge-side');
  
  	//show badge after load
  	objBadge.addClass(fullOpacityClass);
  
    //add side class to objects
  	function addSideClass(sideClass){      
    	objBadge.addClass(sideClass);
    	objForwardWrap.addClass(sideClass);
     	objReverseWrap.addClass(sideClass);
     	objBadgeContainer.addClass(sideClass);   
        objSecondParent.addClass(sideClass);
    }
  	
	//add side class to objects
	function initBadgeSide(){
      if(dataBadgeSide == 'top-left')
      addSideClass(topLeftClass);

      if(dataBadgeSide == 'top-right')
      addSideClass(topRightClass);

      if(dataBadgeSide == 'bottom-right')
      addSideClass(bottomRightClass);

      if(dataBadgeSide == 'bottom-left')
      addSideClass(bottomLeftClass);
    }

	//init positions
	function adjustParentContainersPositionProperties(){      
      objSecondParent.addClass("{{uc_id}}_elementor_container");
      objSecondParent.css({"position": "absolute"});
    }

	//init sides
	initBadgeSide();

	//adjust position property
	adjustParentContainersPositionProperties();    
    	
{{ ucfunc("put_docready_end") }}