/* elementor container settings */
.{{uc_id}}_elementor_container > .elementor-widget-container{
  width: 100%;
  height: 100%;
}
/* end elementor container settings */

/* general styles */
#{{uc_id}}{
  width: 100%;
  height: 100%;
  opacity: 0;
  transition: opacity .2s;
  min-height: 1px;
}

#{{uc_id}}.ue-opacity-full{
  opacity: 1;
}

#{{uc_id}} .ue-badge-rotated-forward{
  overflow: hidden;
}

#{{uc_id}} .ue-badge-rotated-reverse{
  display: flex;
  justify-content: center;
  align-items: center;

}

#{{uc_id}} .ue-badge-container{
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

#{{uc_id}} .ue-badge-icon{
  line-height: 1;
}
/* end general styles */

/* message in editor styles */
#{{uc_id}} .ue-badge-added{
  padding: 10px;
  border: 1px solid grey;
  background-color: lightgrey;
  border-radius: 5px;
  font-size: 12px;
}
/* end message in editor styles */

/* badge side */
/* desktop */
#{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-left,
.{{uc_id}}_elementor_container.ue-badge-top-left{
  top: {{offset_y}} !important;
  left: {{offset_x}} !important;
}

#{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-right,
.{{uc_id}}_elementor_container.ue-badge-top-right{
  top: {{offset_y}} !important;
  right: {{offset_x}} !important;
}

#{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-right,
.{{uc_id}}_elementor_container.ue-badge-bottom-right{
  bottom: {{offset_y}} !important;
  right: {{offset_x}} !important;
}

#{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-left,
.{{uc_id}}_elementor_container.ue-badge-bottom-left{
  bottom: {{offset_y}} !important;
  left: {{offset_x}} !important;
}

/* tablet */
[data-elementor-device-mode="tablet"] #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-left,
[data-elementor-device-mode="tablet"] .{{uc_id}}_elementor_container.ue-badge-top-left{
  top: {{offset_y_tablet}} !important;
  left: {{offset_x_tablet}} !important;
}

[data-elementor-device-mode="tablet"] #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-right,
[data-elementor-device-mode="tablet"] .{{uc_id}}_elementor_container.ue-badge-top-right{
  top: {{offset_y_tablet}} !important;
  right: {{offset_x_tablet}} !important;
}

[data-elementor-device-mode="tablet"] #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-right,
[data-elementor-device-mode="tablet"] .{{uc_id}}_elementor_container.ue-badge-bottom-right{
  bottom: {{offset_y_tablet}} !important;
  right: {{offset_x_tablet}} !important;
}

[data-elementor-device-mode="tablet"] #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-left,
[data-elementor-device-mode="tablet"] .{{uc_id}}_elementor_container.ue-badge-bottom-left{
  bottom: {{offset_y_tablet}} !important;
  left: {{offset_x_tablet}} !important;
}

/* mobile */
[data-elementor-device-mode="mobile"] #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-left,
[data-elementor-device-mode="mobile"] .{{uc_id}}_elementor_container.ue-badge-top-left{
  top: {{offset_y_mobile}} !important;
  left: {{offset_x_mobile}} !important;
}

[data-elementor-device-mode="mobile"] #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-right,
[data-elementor-device-mode="mobile"] .{{uc_id}}_elementor_container.ue-badge-top-right{
  top: {{offset_y_mobile}} !important;
  right: {{offset_x_mobile}} !important;
}

[data-elementor-device-mode="mobile"] #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-right,
[data-elementor-device-mode="mobile"] .{{uc_id}}_elementor_container.ue-badge-bottom-right{
  bottom: {{offset_y_mobile}} !important;
  right: {{offset_x_mobile}} !important;
}

[data-elementor-device-mode="mobile"] #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-left,
[data-elementor-device-mode="mobile"] .{{uc_id}}_elementor_container.ue-badge-bottom-left{
  bottom: {{offset_y_mobile}} !important;
  left: {{offset_x_mobile}} !important;
}
/* end badge side */

/* badge style strip */
{% if badge_style == "strip" %}
  #{{uc_id}} .ue-badge-rotated-reverse{
    width: 150%;
  }

  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-left{
    transform: rotate(0deg);
  }

  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-right{
    transform: rotate(90deg);
  }

  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-right{
    transform: rotate(180deg);
  }

  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-left{
    transform: rotate(-90deg);
  }
{% endif %}	
/* end badge style strip */

/* badge style triangle */
{% if badge_style == "triangle" %}  
  #{{uc_id}}.ue-badge-top-right,
  #{{uc_id}}.ue-badge-bottom-right{
    transform: scale(-1);  
  }

  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-right{
    top: unset;
    right: unset;
	bottom: 0;
    left: 0;
  }

  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-right{
    top: 0;
    right: unset;
	bottom: unset;
    left: 0;
  }

  #{{uc_id}} .ue-badge-container{
    height: 100%;
    width: 100%;
  }

  #{{uc_id}} .ue-badge-container.ue-badge-top-right,
  #{{uc_id}} .ue-badge-container.ue-badge-bottom-right{
    {% if icon_position == "start" %}
      flex-direction: row;
    {% else %}
      flex-direction: row-reverse;
    {% endif %}
  }
 
  #{{uc_id}} .ue-badge-container.ue-badge-top-right > *,
  #{{uc_id}} .ue-badge-container.ue-badge-bottom-right > *{
    transform: rotate(180deg);
  }

  #{{uc_id}} .ue-badge-container.ue-badge-top-right,
  #{{uc_id}} .ue-badge-container.ue-badge-bottom-left{
    transform-origin: 0 100%;
  }	
	
  #{{uc_id}} .ue-badge-container.ue-badge-top-left,
  #{{uc_id}} .ue-badge-container.ue-badge-bottom-right{
    transform-origin: 0 0;
  }	
  
  /* triangle clip path */

  #{{uc_id}} .ue-badge-rotated-reverse.ue-badge-top-left,
  #{{uc_id}} .ue-badge-rotated-reverse.ue-badge-bottom-right{	
    clip-path: polygon(0 0, 100% 0, 0 100%);
  }
	
  #{{uc_id}} .ue-badge-rotated-reverse.ue-badge-top-right,
  #{{uc_id}} .ue-badge-rotated-reverse.ue-badge-bottom-left{
	clip-path: polygon(0 0, 0 100%, 100% 100%);
  }
  /* end triangle clip path */
{% endif %}	
    
/* end badge style triangle */

/* badge style bookmark */
{% if badge_style == "bookmark" %}
  #{{uc_id}}.ue-badge-top-right,
  #{{uc_id}}.ue-badge-bottom-right{
    transform: scale(-1);  
  }

  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-right{
    top: unset;
    right: unset;
	bottom: 0;
    left: 0;
  }

  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-right{
    top: 0;
    right: unset;
	bottom: unset;
    left: 0;
  }

  #{{uc_id}} .ue-badge-rotated-reverse{
    width: 100%;
  }

  /* badge style bookmark offset */
  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-left,
  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-right{ 
    transform-origin: 0 0;
  }

  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-bottom-left,
  #{{uc_id}} .ue-badge-rotated-forward.ue-badge-top-right{ 
    transform-origin: 0 100%;
  }
  /* end badge style bookmark offset */  
{% endif %}	
/* end badge style bookmark */


/* badge style square */
{% if badge_style == "square" %}
  #{{uc_id}} .ue-badge-rotated-forward{
    overflow: unset;
  }
{% endif %}	
/* end badge style square */

/* badge style circle */
{% if badge_style == "circle" %}
  #{{uc_id}} .ue-badge-rotated-forward{
    overflow: unset;
  }

  #{{uc_id}} .ue-badge-rotated-reverse{
    border-radius: 50%;
  }
{% endif %}	
/* end badge style circle */

/* badge style star */
{% if badge_style == "star" %}
  #{{uc_id}} .ue-badge-rotated-forward{
    overflow: unset;
  }

  #{{uc_id}} .ue-badge-rotated-reverse{
    clip-path: polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%);
  }
{% endif %}	
/* end badge style star */