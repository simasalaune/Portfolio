<div class="uc_long_content_box" id="{{uc_id}}">
		<div class="uc_long_content_box_holder">
			
			<div class="uc_long_content_box_box">
				<div class="uc_image_box" style=" background-image: url({{uc_img}});"></div>
				<div class="uc_overlay" ></div>
				<div class="uc_box_content">
					{% if show_title == "true" %}<div class="uc_title">{{uc_long_title|raw}}</div>{% endif %}
					<div class="uc_hidden_content">
						{% if show_text == "true" %}<div class="uc_description">{{uc_long_content|raw}}</div>{% endif %}
						{% if show_button == "true" %}<a {{uc_btn_link_html_attributes|raw}} href="{{uc_btn_link}}" class="uc_btn" >{{uc_btn_label|raw}}</a>{% endif %}
                        {% if show_button_two == "true" %}<a {{button_two_link_html_attributes|raw}} href="{{button_two_link}}" class="uc_btn" >{{button_two_label|raw}}</a>{% endif %}
					</div>
				</div>
			</div>
			
		</div>
    </div>