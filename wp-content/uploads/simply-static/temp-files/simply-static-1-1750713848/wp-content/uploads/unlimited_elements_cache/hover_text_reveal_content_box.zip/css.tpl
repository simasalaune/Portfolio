.uc_long_content_box {
	overflow:hidden;
}
.uc_long_content_box *{
	box-sizing: border-box;
}
#{{uc_id}} .uc_long_content_box_holder{
	position: relative;
    text-align:{{align}};
    overflow:hidden;
}
#{{uc_id}} .uc_long_content_box_holder .uc_long_content_box_box{
	position: relative;
}

#{{uc_id}} .uc_long_content_box_holder .uc_long_content_box_box .uc_image_box{
	position: relative;
	background-size: cover !important;
	background-repeat: no-repeat !important;
	width: 100%;
    background-blend-mode:{{blend_mode}};
}

#{{uc_id}} .uc_long_content_box_holder .uc_long_content_box_box .uc_overlay{
	position: absolute;
	left: 0;
	top: 0;
    right:0;
    bottom:0;
	width: 100%;
	height: 100%;
	z-index: 2;
  transition:{{transition_time_long}}s;
}

#{{uc_id}} .uc_long_content_box_holder .uc_long_content_box_box .uc_box_content{
	left: 0;
    bottom: 0;
    position: absolute;
    margin: 0;
    width: 100%;
	z-index: 3;
	overflow: hidden;
	display: flex;
    height: 100%;
    flex-direction: column;
    justify-content: {{content_align}};
}

#{{uc_id}} .uc_long_content_box_holder .uc_long_content_box_box .uc_box_content .uc_title{
  transition:{{transition_time}}s;	
}

#{{uc_id}} .uc_long_content_box_holder .uc_long_content_box_box .uc_box_content {
  transition:{{transition_time}}s;
  transform: translateY(10px);
}
.uc_title
{
}
#{{uc_id}} .uc_long_content_box_holder:hover .uc_long_content_box_box .uc_box_content .uc_title{
  transform: translateY({{title_hover_gap}}px);	
}
#{{uc_id}} .uc_long_content_box_holder .uc_long_content_box_box .uc_box_content .uc_hidden_content{
	overflow: hidden;
    transform: scaleY(0);
    transform-origin: bottom;
  transition:{{transition_time}}s;
    max-height: 0;
	opacity: 0;
}

#{{uc_id}} .uc_long_content_box_holder:hover .uc_long_content_box_box .uc_box_content .uc_hidden_content{
    max-height: 100%;
    transform: scaleY(1);
    overflow: visible;
	opacity: 1;
	
}

.uc_box_content .uc_description{
	color: #fff;
}
#{{uc_id}} .uc_long_content_box_holder .uc_long_content_box_box .uc_box_content .uc_btn{
	text-decoration: none;
	display: {{button_style}};
    text-align:center;
  transition:{{transition_time}}s;
}

{% if show_content_on_breakpoint == "true" %}
@media only screen and (max-width: {{breakpoint}}px) {
#{{uc_id}} .uc_long_content_box_holder .uc_long_content_box_box .uc_box_content .uc_hidden_content{
    max-height: 100%;
    transform: scaleY(1);
    overflow: visible;
	opacity: 1;
}
}
{% endif %}