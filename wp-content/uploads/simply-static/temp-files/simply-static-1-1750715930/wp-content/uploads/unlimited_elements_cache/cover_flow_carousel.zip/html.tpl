<div class="ue-coverflow {{remote_parent.class|raw}} {{uc_filtering_addclass}} {{uc_dynamic_popup_class}}" id="{{uc_id}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}>
        <ul class="flip-items uc-items-wrapper">
            {{put_items()}}
        </ul>
</div>