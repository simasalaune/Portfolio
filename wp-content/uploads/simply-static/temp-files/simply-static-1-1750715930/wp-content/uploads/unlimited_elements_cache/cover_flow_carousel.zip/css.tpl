#{{uc_id}}{
  display: none;
  min-height: 1px;
}

#{{uc_id}} .flipster__item img{  
  display:block;
  width:100%;
}

#{{uc_id}} .flipster__item__content{
  overflow:hidden;
  position:relative;  
  {% if remove_item_reflection == "true" %}
    -webkit-box-reflect: unset;
    box-reflect: unset;
  {% endif %}
}

#{{uc_id}} .flipster__nav__item a{
  z-index:1;
}

.ue-flip-item-title{
  font-size:21px;
}

#{{uc_id}} .ue-item-btn a{
  text-decoration:none;
  text-align:center;
  transition:0.3s;
}

{% if content_layout == "overlay" %}
   #{{uc_id}} .ue-flip-item-content    {
      position:absolute;
      top:0;
      left:0;
      right:0;
      bottom:0;
      display:flex;
      flex-direction:column;
      align-items:center;
      justify-content:center;
      transition:0.3s;
    }
{% endif %}

#{{uc_id}} .flipster__button{
  line-height:1em;
  margin:0;
}

#{{uc_id}} .ue-flip-item-icon{
  line-height:1em;
  display:inline-flex;
  justify-content:center;
  align-items:center;  
}

#{{uc_id}} .ue-flip-item-icon svg{
  height:1em;
  width:1em;
}

#{{uc_id}} .flipster__container, 
#{{uc_id}} .flipster__item, 
#{{uc_id}} .flipster__item__content{
  transition:{{transition_duration}}ms;
}

#{{uc_id}} .flipster__nav__link::after{
  background-color:{{navigation_color}};
}

#{{uc_id}} .flipster__nav__item a{
  color:{{navigation_text_color}};
}

#{{uc_id}} .flipster__nav__item--current>.flipster__nav__link{
  color:{{navigation_text_color_selected}};
}