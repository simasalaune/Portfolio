{# twig vars #}{##}
{% set ueFlipBoxPanelElementClass = "ue-flip-box__panel__element" %}
{% set ueFlipBoxIconClass = "ue-flip-box__icon" %}
{% set graphicElementElem %}
  {% if graphic_element_front == "icon" %} <div class="{{ueFlipBoxPanelElementClass}} {{ueFlipBoxIconClass}}">{{icon_front_html|raw}}</div> {% endif %}
  {% if graphic_element_front == "img" %} <div class="{{ueFlipBoxPanelElementClass}} {{ueFlipBoxIconClass}}"><img src="{{graphic_img_front}}" title="{{graphic_img_front_title}}" alt="{{graphic_img_front_alt}}" {{graphic_img_front_attributes|raw}}></div> {% endif %}
  {% if graphic_element_front == "txt" %} <div class="{{ueFlipBoxPanelElementClass}} {{ueFlipBoxIconClass}}">{{graphic_txt_front|raw}}</div> {% endif %}
{% endset %}{# end graphicElementElem #}{##}
{% set graphicElementBackElem %}
  {% if graphic_element_back == "icon" %}<div class="{{ueFlipBoxPanelElementClass}} {{ueFlipBoxIconClass}}">{{icon_back_html|raw}}</div>{% endif %}
  {% if graphic_element_back == "img" %}<div class="{{ueFlipBoxPanelElementClass}} {{ueFlipBoxIconClass}}"><img src="{{graphic_img_back}}" title="{{graphic_img_back_title}}" alt="{{graphic_img_back_alt}}" {{graphic_img_back_attributes|raw}}></div> {% endif %}
  {% if graphic_element_back == "txt" %} <div class="{{ueFlipBoxPanelElementClass}} {{ueFlipBoxIconClass}}">{{graphic_txt_back|raw}}</div> {% endif %}
{% endset %}{# end graphicElementBackElem #}{##}
{# end twig vars #}{##}

<div id="{{uc_id}}" class="ue-flip-box" data-id="{{uc_id}}" data-closeonbody='{{close_on_body_click}}'>
  
  {% if ( anim_effect == "ue-fade" ) or ( anim_effect == "ue-zoomin" ) or ( anim_effect == "ue-zoomout" ) or ( anim_effect == "ue-zoominout" )%}
  	<div class="ue-flip-box__container uc-hide {{anim_effect}} ue-flip-box__container--{{animation_trigger}}" tabindex="0">
  {% else %}
    <div class="ue-flip-box__container uc-hide {{anim_effect}}_{{anim_direction}} ue-flip-box__container--{{animation_trigger}}" tabindex="0">
  {% endif %}
    
    <div class="ue-flip-box__panel ue-flip-box__panel--front">
      <div class="ue-flip-box__panel--front-overlay"></div>
      {% if animation_trigger == "trigger_button" %}<a href="javascript:void(0)" class="ue-flip-box__front-trigger">{{front_trigger_button_html|raw}}</a>{% endif %}
      <div class="ue-flip-box__panel__wrapper">
        <div class="ue-flip-box__panel__content">
          {% if (show_front_icon == "true") and (graphic_element_position == "above_title") %}{{graphicElementElem}}{% endif %}
          {% if show_front_title == "true" %}<div class="{{ueFlipBoxPanelElementClass}} ue-flip-box__title">{{title_front|raw}}</div>{% endif %}
          {% if show_front_icon == "true" and (graphic_element_position == "below_title") %}{{graphicElementElem}}{% endif %}
          {% if show_front_text == "true" %}<div class="{{ueFlipBoxPanelElementClass}} ue-flip-box__description">{{description_front|raw}}</div>{% endif %}
        </div>{# end ue-flip-box__panel__content #}{##}
      </div>{# end ue-flip-box__panel__wrapper #}{##}
    </div>{# end ue-flip-box__panel--front #}{##}
      
    <div class="ue-flip-box__panel ue-flip-box__panel--back">
      <div class="ue-flip-box__panel--back-overlay"></div>
      {% if animation_trigger == "trigger_button" and show_back_trigger_button == "true" %}<a href="javascript:void(0)" class="ue-flip-box__back-trigger">{{back_trigger_button_html|raw}}</a>{% endif %}
      <div class="ue-flip-box__panel__wrapper">
        <div class="ue-flip-box__panel__content">
          {% if (show_back_icon == "true") and (graphic_element_position == "above_title") %}{{graphicElementBackElem}}{% endif %}
          {% if show_back_title == "true" %}<div class="{{ueFlipBoxPanelElementClass}} ue-flip-box__title">{{title_back|raw}}</div>{% endif %}
          {% if (show_back_icon == "true") and (graphic_element_position == "below_title") %}{{graphicElementBackElem}}{% endif %}
          {% if show_back_text == "true" %}<div class="{{ueFlipBoxPanelElementClass}} ue-flip-box__description">{{description_back|raw}}</div>{% endif %}
          {% if (show_back_button == "true") and (button_text is not empty) %}<div class="{{ueFlipBoxPanelElementClass}} ue-flip-box__button"><a href="{{button_link}}" class="ue_btn" {{button_link_html_attributes|raw}}>{{button_text|raw}}</a></div>{% endif %}
          {% if (enable_back_panel_link == "true") and (back_panel_link is not empty) %}<a href="{{back_panel_link}}" class="ue_back_panel_link" {{back_panel_link_html_attributes|raw}}></a>{% endif %}
        </div>{# end ue-flip-box__panel__content #}{##}
      </div>{# end ue-flip-box__panel__wrapper #}{##}
    </div>{# end ue-flip-box__panel--back #}{##}
    
  </div>{# end ue-flip-box__container #}{##}
      
  {% if show_overlay == "true" %}
  	<div class="ue-flip-box__overlay"></div>
  {% endif %}
      
</div>{# end ue-flip-box #}{##}