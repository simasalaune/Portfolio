/* elementor container support */
.e-con-inner>.elementor-widget-ucaddon_flip_box, .e-con>.elementor-widget-ucaddon_flip_box {
    width: var(--container-widget-width);
    --flex-grow: var(--container-widget-flex-grow);
}

#{{uc_id}} .ue-flip-box__panel.ue-flip-box__panel--front,
#{{uc_id}} .ue-flip-box__panel.ue-flip-box__panel--back {
    backface-visibility: hidden;
    -webkit-backface-visibility: hidden; 
}

#{{uc_id}} .ue-flip-box__container .ue-flip-box__panel--back {
  z-index: -1;
}

#{{uc_id}} .ue-flip-box__container .ue-flip-box__panel--front {
  z-index: 1;
}

#{{uc_id}} .ue-flip-box__container.uc-show .ue-flip-box__panel--back {
  z-index: 1;
}

#{{uc_id}} .ue-flip-box__container.uc-show .ue-flip-box__panel--front {
  z-index: -1;
}

#{{uc_id}} .ue-flip-box__panel__wrapper{
  pointer-events: all;
}

#{{uc_id}} .ue-flip-box__panel--back .ue_btn{
	display: {{button_style}};
}

{% if ( anim_effect == "ue-flip" ) or ( anim_effect == "ue-flip-alt" )  %} 

	{% if add_3d_depth == "true"  %}
        #{{uc_id}} .ue-flip-box__panel__wrapper { 
            transform: translateZ(90px) scale(0.91);
            transform-style: preserve-3d;
        }	
		#{{uc_id}} .uc-show .ue-flip-box__panel__wrapper{
          pointer-events: none;
        }
    {% endif %}

{% else %}
	
	#{{uc_id}} .ue-flip-box__container, #{{uc_id}} .ue-flip-box__panel {
      overflow: hidden;
    }
	
{% endif %}

{% if show_overlay == "true" %}
  #{{uc_id}} .ue-flip-box__overlay {
    position: fixed;
  	top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
  	opacity: 0;
  	z-index: -1;
  	transition: all 0.3s;
    bottom:0;
    right:0;
  }

  #{{uc_id}} .ue-flip-box__container.uc-show { 
      z-index: 3;
  }

  #{{uc_id}} .ue-flip-box__container.uc-show + .ue-flip-box__overlay { 
    	opacity: 1;
    	z-index: 2;
  }

{% endif %}

{% if animation_trigger == "trigger_button" %}

  #{{uc_id}} .ue-flip-box__front-trigger{
    position:absolute;
    {{front_trigger_horizontal_position}}:{{front_trigger_horizontal_spacing}}px;
    {{front_trigger_vertical_position}}:{{front_trigger_vertical_spacing}}px;
    cursor:pointer;
    line-height:1em;
    display:block;
  }

  #{{uc_id}} .ue-flip-box__front-trigger svg{
    width:1em;
    height:1em;
  }

  #{{uc_id}} .ue-flip-box__back-trigger{
    position:absolute;
    {{back_trigger_horizontal_position}}:{{back_trigger_horizontal_spacing}}px;
    {{back_trigger_vertical_position}}:{{back_trigger_vertical_spacing}}px;
    cursor:pointer;
    line-height:1em;
    display:block;
  }

  #{{uc_id}} .ue-flip-box__back-trigger svg{
    width:1em;
    height:1em;
  }

{% endif %}

#{{uc_id}} .ue-flip-box__panel--front-overlay, 
#{{uc_id}} .ue-flip-box__panel--back-overlay{
  position:absolute;
  top:0;
  bottom:0;
  right:0;
  left:0;
  z-index:-1;
}

{% if graphic_element_front == "img" %}

  #{{uc_id}} .ue-flip-box__panel--front .ue-flip-box__icon img{
    max-width: none;
  }

{% endif %}

{% if graphic_element_back == "img" %}

  #{{uc_id}} .ue-flip-box__panel--back .ue-flip-box__icon img{
    max-width: none;
  }

{% endif %}

{% if enable_back_panel_link == "true" %}
#{{uc_id}} .ue_back_panel_link{
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  right: 0;
  z-index: 1;
}
{% endif %}