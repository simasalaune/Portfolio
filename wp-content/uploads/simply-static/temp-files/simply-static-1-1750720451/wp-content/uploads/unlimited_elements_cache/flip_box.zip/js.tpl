jQuery(document).ready(function(){	
function {{uc_id}}_start(){

  new UEFlipbox("#{{uc_id}}");
    	
}setTimeout(function(){if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});},100);
});