<div class="blox-border-left-blockquote" style="text-align:left;">
    	<div class="blox-content" style=" border-color:{{border_color}}; background-color:#ffffff;">
        	{% if icon is not empty %}<i style="background-color:{{icon_bg_color}};" class="{{icon}}"></i>{% endif %}
            <div class="blox-box">	
        		{{description|raw}}
            </div>
           	<div style="color:#BBC1C4;" class="blox-author">{{title|raw}}</div>
        </div>
    </div>